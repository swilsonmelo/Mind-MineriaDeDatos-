import pandas as pd


data = {'primer nombre': ['luis', 'pedro', 'julian'],
        'segundo nombre': ['Francisco', 'Juan', 'Andres'],
        'estatura_m': [1.8, 1.65, 1.72],
        'estudia': ['No','Si','Si']
        }

df = pd.DataFrame(data)
df['Estatura_in'] = df['estatura_m'] * 39.3701

print(df)